###############################     INSTALLATION/PREP     ################
# This is a code template for logistic regression using stochastic gradient ascent to be completed by you 
# in CSI 431/531 @ UAlbany
#


###############################     IMPORTS     ##########################
import numpy as np
import pandas as pd
import math as mt
from numpy import linalg as li
import matplotlib.pyplot as plt


###############################     FUNCTION DEFINITOPNS   ##########################

"""
Receives data point x and coefficient parameter values w 
Returns the predicted label yhat, according to logistic regression.
"""
def predict(x, w):
    """
      TODO
    """
    score = np.dot(x, w)
    yhat = 1.0 / (1.0 + np.exp(-score))
    return(yhat)
      
    
"""
Receives data point (x), data label (y), and coefficient parameter values (w) 
Computes and returns the gradient of negative log likelihood at point (x)
"""
def gradient(x, y, w):
    """
      TODO
    """
    score = np.dot(x, w)
    grad = np.sum(y * score - np.log(1 + np.exp(score)))
    return(grad)


"""
Receives the predicted labels (y_hat), and the actual data labels (y)
Computes and returns the cross-entropy loss
"""
def cross_entropy(y_hat, y):
    """
      TODO
    """
    cross_ent = yhat - y
    return(cross_ent)
    


"""
Receives data set (X), dataset labels (y), learning rate (step size) (psi),
stopping criterion (for change in norm of ws) (epsilon), and maximum number of
epochs (max_epochs)
Computes and returns the vector of coefficient parameters (w),
and the list of cross-entropy losses for all epochs (cross_ent)
"""
def logisticRegression_SGA(X, y, psi, epsilon, max_epochs):
    """
      TODO
      NOTE: remember to either shuffle the data points or select data points
      randomly in each internal iteration.
      NOTE: stopping criterion: stop iterating if norm of change
      in w (norm(w-w_old)) is less than epsilon, or the number of epochs
      (iterations over the whole dataset) is more than maximum number of epochs
    """
    cross_ent = []
    
    # Suffle the data before starting
    per = np.random.permutation(len(X))
    y = y[per]
    ind = 0 # Index of current batch starts from zero
    w = np.zeros(X.shape[1]) # Defining initial weights as zero with shape of input data
    
    for l in range(max_epochs): # Loop until max epochs reach
        # we will make prediction based on our predict funciton that we have defined above
        pred = predict(X, w)
        
        cross_ent = y - pred

        grad = gradient(X, y, w)

        w += psi * grad
    return(w,cross_ent)    
  
  
if __name__ == '__main__':  
    ## initializations and config
    psi=0.1 # learning rate or step size
    epsilon = 10 # used in SGA's stopping criterion to define the minimum change in norm of w
    max_epochs = 8 # used in SGA's stopping criterion to define the maximum number of epochs (iterations) over the whole dataset
    
    ## loading the data
    df_train = pd.read_csv("cancer-data-train.csv", header=None)
    df_test = pd.read_csv("cancer-data-test.csv", header=None)
    
    ## split into features and labels
    X_train, y_train = df_train.iloc[:, :-1], df_train.iloc[:, -1].astype("category").cat.codes #Convert string labels to numeric
    X_test, y_test = df_test.iloc[:, :-1], df_test.iloc[:, -1].astype("category").cat.codes
    
    ## augmenting train data with 1 (X0)
    X_train.insert(0,'',1)
    X_test.insert(0,'',1)
    
    
    ## learning logistic regression parameters
    [w, cross_ent] = logisticRegression_SGA(X_train, y_train, psi, epsilon, max_epochs)
    
    
    ## plotting the cross-entropy across epochs to see how it changes
    plt.plot(cross_ent, 'o', color='black');
    
    
    """
      TODO: calculate and print the average cross-entropy error for training data (cross-entropy error/number of data points)
      
    """
    print("Average Cross Entropy Error:", np.sum(cross_ent)/X_train.shape[0])
    """
      TODO: predict the labels for test data points using the learned w's
    """
    pred = []
    cross_ent = []
    for l in range(X_test.shape[1]): # Loop through all of test data
            # we will make prediction based on our predict funciton that we have defined above
            pred = predict(X_test, w)
            cross_ent = y_test - pred
    """
      TODO: calculate and print the average cross-entropy error for testing data (cross-entropy error/number of data points)
    """
  print("Average Cross Entropy Error of Test Data:", np.sum(cross_ent)/X_test.shape[0])
